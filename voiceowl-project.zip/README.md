# VoiceOwl Starter Project (Backend + Frontend)

This zip contains two folders:
- voiceowl-backend: Node.js + TypeScript backend (mock transcription)
- voiceowl-frontend: Vite + React frontend to test API

Follow each README inside the folders to run locally.

Notes:
- This is a starter project. The backend mocks download and transcription.
- To enable real DB, set MONGO_URI in .env (or run local MongoDB).
