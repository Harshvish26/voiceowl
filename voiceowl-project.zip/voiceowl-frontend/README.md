# VoiceOwl Frontend (Starter)

## How to run
1. `npm install`
2. `npm run dev`
3. Open the Vite URL (usually http://localhost:5173)
